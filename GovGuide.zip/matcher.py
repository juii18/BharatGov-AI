import json

def load_schemes():
    with open("schemes.json", "r") as f:
        return json.load(f)

def match_schemes(user_input):
    schemes = load_schemes()
    results = []

    for scheme in schemes:
        if scheme["eligibility"].lower() in user_input.lower():
            results.append(scheme)

    return results
