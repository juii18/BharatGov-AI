import streamlit as st
from model import GovGuideModel

# Page config
st.set_page_config(
    page_title="GovGuide – Scheme Finder",
    page_icon="🏛️",
    layout="wide"
)

# Custom CSS styling
st.markdown("""
<style>
.main-title {
    font-size: 40px;
    font-weight: bold;
    color: #1f77b4;
    text-align: center;
}

.subtitle {
    font-size: 18px;
    text-align: center;
    color: gray;
}

.scheme-card {
    background-color: #f0f2f6;
    padding: 15px;
    border-radius: 10px;
    margin-bottom: 10px;
}
</style>
""", unsafe_allow_html=True)

# Header
st.markdown('<div class="main-title">🏛️ GovGuide</div>', unsafe_allow_html=True)
st.markdown('<div class="subtitle">Find Government Schemes Based on Your Eligibility</div>', unsafe_allow_html=True)

st.write("")
st.write("")

# Load model
model = GovGuideModel()

# Input section
col1, col2, col3 = st.columns([1,2,1])

with col2:
    user_input = st.text_input(
        "Enter your occupation or situation",
        placeholder="Example: farmer, student, worker"
    )

    search = st.button("🔍 Find Schemes")

st.write("")
st.write("")

# Output section
if search:

    if user_input:

        results = model.recommend(user_input)

        if not results.empty:

            st.success(f"Found {len(results)} matching schemes")

            for index, row in results.iterrows():

                st.markdown(f"""
                <div class="scheme-card">
                <h4>📌 {row['scheme_name']}</h4>
                <b>Benefits:</b> {row['benefits']}<br>
                <b>Eligibility:</b> {row['eligibility']}
                </div>
                """, unsafe_allow_html=True)

        else:
            st.error("No matching schemes found")

    else:
        st.warning("Please enter occupation")

# Footer
st.write("")
st.write("---")
st.markdown("Built using Python, Streamlit, and Government Scheme Dataset")
