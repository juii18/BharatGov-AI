import pandas as pd

class GovGuideModel:

    def __init__(self):
        self.data = pd.read_csv("updated_data.csv")

    def recommend(self, user_input):

        results = self.data[
            self.data["eligibility"].astype(str).str.lower().str.contains(user_input.lower(), na=False)
        ]

        return results
